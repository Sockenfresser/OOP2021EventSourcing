﻿using Xunit;

namespace CarSharing.Test
{
    public class UnitTest
    {
        [Fact]
        public void TestMethod1() { }
    }
}