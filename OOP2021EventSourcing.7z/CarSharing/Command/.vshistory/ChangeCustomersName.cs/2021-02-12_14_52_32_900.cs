﻿namespace CarSharing.Command
{
    public class ChangeCustomersName
    {
        
    }
}