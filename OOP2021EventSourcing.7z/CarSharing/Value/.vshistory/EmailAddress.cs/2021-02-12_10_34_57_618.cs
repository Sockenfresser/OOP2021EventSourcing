﻿namespace ConsoleApp1.Domain.Customer.Value
{
    public class EmailAddress
    {
        public string Value { get; }

        public EmailAddress(string emailAddress)
        {
            EmailAddress = emailAddress;
        }
    
    }
}
