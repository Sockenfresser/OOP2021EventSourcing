﻿namespace ConsoleApp1.Domain.Customer.Value
{
    public class ID
    {
        public static ID Generate()
        {
            return null;
        }
    }
}
