﻿namespace ConsoleApp1.Domain.Customer.Value
{
    public class PersonName
    {
        public static PersonName Build(string givenName, string familyName)
        {
            return null;
        }
    }
}
