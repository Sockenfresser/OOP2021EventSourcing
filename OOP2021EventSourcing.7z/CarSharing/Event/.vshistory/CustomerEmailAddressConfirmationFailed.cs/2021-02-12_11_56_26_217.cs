﻿namespace CarSharing.Event
{
    public class CustomerEmailAddressConfirmationFailed
    {
        
    }
}