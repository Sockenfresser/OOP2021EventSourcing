﻿$HEADER$namespace $NAMESPACE$
{
  public interface $INTERFACE$ {$END$}
}