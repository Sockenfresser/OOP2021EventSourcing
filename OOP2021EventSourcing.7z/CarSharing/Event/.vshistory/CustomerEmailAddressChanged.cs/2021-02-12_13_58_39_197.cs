﻿namespace CarSharing.Event
{
    public class CustomerEmailAddressChanged
    {
        
    }
}