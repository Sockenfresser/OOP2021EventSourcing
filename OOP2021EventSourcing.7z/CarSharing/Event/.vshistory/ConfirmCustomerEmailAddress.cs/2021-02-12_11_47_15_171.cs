﻿namespace CarSharing.Event
{
    public class ConfirmCustomerEmailAddress
    {
        
    }
}