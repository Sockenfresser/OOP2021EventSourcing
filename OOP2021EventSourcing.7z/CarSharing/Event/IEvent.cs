﻿namespace CarSharing.Event
{
    public interface IEvent
    {
        
    }
}