﻿namespace CarSharing.Command
{
    public class ChangeCustomerEmailAddress
    {
        
    }
}