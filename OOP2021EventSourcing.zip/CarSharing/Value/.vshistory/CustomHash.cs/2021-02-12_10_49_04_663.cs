﻿namespace CarSharing.Value
{
    public class CustomHash
    {
        public CustomHash()
        {
        }
    }
}
