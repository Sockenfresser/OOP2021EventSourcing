﻿namespace ConsoleApp1.Domain.Customer.Value
{
    public class CustomHash
    {
        public static CustomHash Generate()
        {
            return null;
        }
    }
}
