﻿namespace ConsoleApp1.Domain.Customer.Value
{
    public class EmailAddress
    {
        public static EmailAddress Build(string emailAddress)
        {
            return null;
        }
    
    }
}
