﻿namespace CarSharing.Event
{
    public class CustomerNameChanged
    {
        
    }
}