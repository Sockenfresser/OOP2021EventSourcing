﻿namespace CarSharing.Event
{
    public class CustomerEmailAddressConfirmed
    {
        
    }
}