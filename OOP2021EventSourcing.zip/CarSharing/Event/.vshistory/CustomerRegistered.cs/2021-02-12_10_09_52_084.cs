﻿namespace CarSharing.Event
{
    public class CustomerRegistered
    {
        
    }
}