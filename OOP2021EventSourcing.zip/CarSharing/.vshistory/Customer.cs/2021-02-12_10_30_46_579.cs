﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarSharing
{
    public class Customer
    {
        public static Event.CustomerRegistered Register(Command.RegisterCustomer registerCustomer)
        {
            throw new NotImplementedException();
        }
    }
}
