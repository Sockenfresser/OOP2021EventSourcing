﻿$HEADER$namespace $NAMESPACE$
{
  public class $CLASS$ {$END$}
}