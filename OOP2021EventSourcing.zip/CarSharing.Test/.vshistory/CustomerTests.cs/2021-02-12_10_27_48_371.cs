﻿using Xunit;

namespace CarSharing.Test
{
    public class CustomerTests
    {
        [Fact]
        public void Register_Scenario_Expectation()
        {
            // when
            new Regi

            // then

            
        }
    }
}